#' PLX4720 Dataset
#'
#' A dataset for use in wCI package examples
#'
#' @format A dataframe with 534 rows and 2 variables
#'
"PLX4720_data"