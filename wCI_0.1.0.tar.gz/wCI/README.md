# wCI
Modified Concordance Index for pharmacological readout

How to install: At present there are 2 ways to install:
First, you will need devtools. Install devtools in R as:
 	```R
      install.packages("devtools")
      library(devtools) #load library
      ```

1- Download zip file from mCI github page. Unzip it. and install 
    ```R
    devtools::install("mCI-master")
    ```
 
2- Using install_github :  
      ```R
      devtools::install_github("bhklab/mCI")
      ```
