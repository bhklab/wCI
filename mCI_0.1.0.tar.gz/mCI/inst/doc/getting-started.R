## ----setup, include=FALSE--------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
require(devtools)

## ---- results='hide',warning=FALSE,error=FALSE-----------------------------
devtools::install_github("bhklab/mCI")

## ----ci1-------------------------------------------------------------------
library(mCI)

## ----ci2,results='hold'----------------------------------------------------
  load("../data/PLX4720_data.rda")

## ---- fig.show='hold'------------------------------------------------------
plot(PLX4720_data[,"AAC_CTRPv2"],PLX4720_data[,"AAC_GDSC"], 
  main = "AAC drug response consistency between CTRPv2 and GDSC\nPLX4720 drug 
  as an example", xlab = "CTRPv2[AAC]", ylab = "GDSC[AAC]", xlim = c(0,0.5),
  ylim = c(0,0.5))

## ----ci3-------------------------------------------------------------------
paired.concordance.index(predictions = PLX4720_data[,"AAC_CTRPv2"],
                         observations = PLX4720_data[,"AAC_GDSC"],
                         delta.pred = 0, 
                         delta.obs = 0,
                         outx = TRUE)$cindex

## ----ci4-------------------------------------------------------------------
paired.concordance.index(predictions = PLX4720_data[,"AAC_CTRPv2"], 
                          observations = PLX4720_data[,"AAC_GDSC"],
                          delta.pred = 0.2, 
                          delta.obs = 0.2,
                          outx = TRUE)$cindex

